<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../novo_design_adm.css"/>
</head>
<body>
    <div id="divMain">
    <form action="inserir_ok.php" method="POST">
        <label for="nome">Nome</label>
        <input id="nome" type="text" name="Nome"/>
        <button type="submit">Enviar</button>
    </form> 
    </div>
</body>
</html>