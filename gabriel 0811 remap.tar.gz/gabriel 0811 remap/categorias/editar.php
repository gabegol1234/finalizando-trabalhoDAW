<?php
include_once "../class/categorias.class.php";
include_once "../class/categoriasDAO.class.php";

$idCategoria = $_GET["idCategoria"];
$objDAO = new categoriasDAO();
$retorno = $objDAO->retornarUm($idCategoria);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../novo_design_adm.css"/>
</head>
<body>
    <div id="divMain">
    <form action="editar_ok.php" method="POST">
        idCategoria
    
        <input disabled="disabled" type="text" value="<?=$idCategoria?>" />
        
       
        nome
        
        <input type="text" name="nome" value="<?= isset($retorno["nome"]) ? $retorno["nome"] : '' ?>" />
      
        <input type="hidden" name="idCategoria" value="<?= $idCategoria ?>" />
        <button type="submit">Salvar</button>
    </form>
    </div>
</body>

</html>