<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../novo_design_adm.css" />
</head>
<body>
    <div id="divMain">
        <form action="inserir_ok.php" method="POST">
            Nome
            <input type="text" name="nome"/>
            
            Usuário
            <input type="text" name="usuario"/>
            
            Contato
            <input type="number" name="contato"/>
        
            CPF         
            <input type="text" name="cpf"/>
            
            Senha
            <input type="text" name="senha"/>
            
            <button type="submit">Enviar</button>
            
        </form>
    </div>
</body>
</html>
