<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Filmoteca</title>
    <link rel="stylesheet" type="text/css" href="../estilo.css"/>
</head>
<body>
<?php
require_once "../sobreEmpresa/header.php";
?>
<body>
<a href="index.php"><button style="font-size: 15px; font-weight: bold;">Retornar à página inicial</button></a>
    <form action="login_ok.php"method="POST">
    usuario: <input type="text" name="usuario">
    <br>
    Senha: <input type="Senha" name="senha">
    <br>
     <button type="submit">Enviar</button>
     </form>
</body>
</body>
</div>
<br>
<br>
<br>
<br>
<br>
<footer style="background-color:#1c1c1c; color:white; text-align:center; padding:10px;">
    <p>Filmoteca © 2025</p>
    <nav>
        <a href="../sobreEmpresa/sobre.php" style="color:white;">Sobre nós</a> | 
        <a href="../sobreEmpresa/contato.php" style="color:white;">Contato</a> | 
        <a href="../sobreEmpresa/privacidade.php" style="color:white;">Política de Privacidade</a>
    </nav>
</footer>
</html>