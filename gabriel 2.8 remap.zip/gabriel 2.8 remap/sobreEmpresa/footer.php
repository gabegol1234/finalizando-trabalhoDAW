<footer>
    <div>Filmoteca © 2025</div>
    <nav>
        <a href="../sobreEmpresa/sobre.php">Sobre nós</a> |
        <a href="../sobreEmpresa/contato.php">Contato</a> |
        <a href="../sobreEmpresa/privacidade.php">Política de Privacidade</a>
    </nav>
</footer>