<?php 
include_once "../class/clientes.class.php";
include_once "../class/clientesDAO.class.php";

$obj = new Clientes();
$obj->setIdCliente($_POST["id"]);
$obj->setUsuario($_POST["usuario"]);
$obj->setSenha($_POST["senha"]);
$obj->setResposta_seguranca($_POST["resposta"]);

$objDAO = new clientesDAO();
$retorno = $objDAO->alterarSenha($obj);

if($retorno == 2)
    echo "email não cadastrado";
else if($retorno == 1)
    echo "resposta incorreta";
else{
    echo "senha alterada com sucesso, realize o login";
}
?>