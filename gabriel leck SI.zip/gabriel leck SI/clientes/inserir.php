<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="inserir_ok.php" method="POST">
        nome:
        <input type="nome" name="nome"/>
        <br>
        usuario:
        <input type="email" name="usuario"/>
        <br>
        contato:
        <input type="number" name="contato"/>
        <br>
        cpf:
        <input type="text" name="cpf"/>
        <br>
        senha:
        <input type="password" name="senha"/>
        <br>
        pergunta para recuperação de senha:
        <input  type="text" name="pergunta"/>
        <br>
        reposta da perguta:
        <input  type="text" name="resposta"/>
        <br>
        <button type="submit">enviar</button>
        <br>
        
</body>
</html>