<?php 
include_once "../class/clientes.class.php";
include_once "../class/clientesDAO.class.php";

$obj = new clientes();
$obj->setUsuario($_POST["usuario"]);
$objDAO = new clientesDAO();
$retorno = $objDAO->retornarUmPorUsuario($_POST["usuario"]);
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="pergunta_ok.php"method="POST">
        Pergunta de seguranca do usuario: <?php echo $_POST['usuario']?><br>
        <h3><?php echo $retorno['pergunta_seguranca']?></h3>
        sua resposta:
        <input type="text" name="resposta"/>
        sua nova senha:
        <input type="password" name="senha"/>
        <br>
        <input type="hidden" name="id" value="<?php echo $retorno['idCliente']?>">
        <input type="hidden" name="usuario" value="<?php echo $_POST['usuario']?>">
        <button type= submit>Enviar Resposta</button>
    </form>
</body>
</html>