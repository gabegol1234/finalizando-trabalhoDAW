<?php
//echo"<pre>";
//print_r($_POST);
include_once "../class/clientes.class.php";
include_once "../class/clientesDAO.class.php";


$obj = new Clientes();
$obj->setUsuario($_POST["usuario"]);
$obj->setSenha($_POST["senha"]);

$ip = $_SERVER['REMOTE_ADDR']; //pega o nosso IP
$captcha = $_POST['g-recaptcha-response']; //resultado do captcha no formulário de login
$chave_secreta = "6LfJVvwrAAAAALaqjpO72218ohWyisIYyAxomOPI"; // chave secreta do nosso captcha

$resposta_captcha = file_get_contents(
    "https://www.google.com/recaptcha/api/siteverify?secret=$chave_secreta&response=$captcha&remoteip=$ip");
    //atribui a  resposta  do pedido de validação para o servidor a uma variável

$atributos_captcha = json_decode($resposta_captcha, TRUE);//decodificação resposta enviada pelo servidor

if($atributos_captcha['success']==true){//if que verifica se o captcha funcionou

$objDAO = new ClientesDAO();
$retorno = $objDAO->login($obj);

if($retorno == 2)
    echo "email nao cadastrado";
else if($retorno == 1)
    echo "senha incorreta";
else{
    session_start();
    $_SESSION["idCliente"] = $retorno["idCliente"];
    $_SESSION["login"] = true;
    header("location:index.php?loginok");
}

}else{//else que é acionado caso o captcha falhe
    echo "Verifique o Captcha";
}